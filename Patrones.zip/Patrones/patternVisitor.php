<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require_once './secciones/head.php'; ?>
    </head>
    <body>

        <!-- Header -->
        <?php require_once './secciones/header.php'; ?>

        <!--================Banner Area =================-->
        <section class="banner_area">
            <div class="container">
                <div class="banner_text_inner">
                    <h4>Pattern Visitor</h4>
                </div>
            </div>
        </section>

        <!--================Static Area =================-->
        <section class="static_area">
            <div class="container">
                <div class="static_inner">
                    <div class="row">
                        <div class="col-lg-9">
                            <div>
                                <h3 style="margin-bottom: 15px;"><strong>Descripción</strong></h3>
                                <p style="margin-bottom: 25px;">El patrón de visitante define una nueva operación para una colección de objetos 
                                sin cambiar los objetos en sí. La nueva lógica reside en un objeto separado llamado el visitante. </p>

                                <p style="margin-bottom: 25px;">Los visitantes son útiles cuando se construye la extensibilidad en una 
                                    biblioteca o marco. Si los objetos en su proyecto proporcionan un método de 'visita' que acepta un objeto 
                                    Visitante que puede hacer cambios en el objeto receptor, entonces está proporcionando una manera fácil para 
                                    que los clientes implementen futuras extensiones.</p>
                                
                                <p style="margin-bottom: 25px;">En la mayoría de los lenguajes de programación, el patrón de Visitante requiere
                                    que el desarrollador original anticipa ajustes funcionales en el futuro. Esto se hace mediante la inclusión de 
                                    métodos que aceptan a un visitante y le permiten operar en la colección original de objetos</p>

                                <p style="margin-bottom: 25px;">Visitor no es importante para JavaScript porque ofrece mucha más flexibilidad gracias a la capacidad 
                                    de agregar y eliminar métodos en tiempo de ejecución.</p>
                            </div>
                            <div class="static_img text-center" style="border: 1px solid grey; border-radius: 10px; padding: 10px;">
                                <p style="font-size: 20px; margin-bottom: 15px;">Diagrama</p>
                                <img class="img-fluid" src="img/patrones/diagram-patternVisitor.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="right_sidebar_area">
                                <aside class="right_widget r_news_widget">
                                    <div class="r_w_title">
                                        <h3>Participantes</h3>
                                    </div>
                                    <div class="news_inner">
                                        <div class="news_item">
                                            <h4><strong>Los objetos que participan en éste patrón son</strong></h4>
                                            <h4>ObjectStructure: en el código de muestra: Employets array 
                                                mantiene una colección de elementos que se pueden iterar sobre</h4>
                                        </div>
                                        <div class="news_item">
                                            <h4>Elements: en el código de muestra: Employee objects 
                                                define un método de aceptación que acepta objetos de visitante 
                                                en el método de aceptación. Se invoca el método de visita del visitante. con 'esto' como parámetro </h4>
                                        </div>
                                        <div class="news_item">
                                           <h4>Visitante - En el código de muestra: ExtraSalary, ExtraVacation 
                                                implementa un método de visita. El argumento es el elemento que está siendo visitado. 
                                                Aquí es donde se hacen los cambios del Elemento.</h4>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Static Area =================-->

        <!--================Footer Area =================-->
        <?php require_once './secciones/footer.php'; ?>
        <!--================End Footer Area =================-->


        <?php require_once './secciones/scripts.php'; ?>
    </body>
</html>
