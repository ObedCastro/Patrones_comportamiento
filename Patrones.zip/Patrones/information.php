<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once './secciones/head.php' ?>
</head>
<body>

    <?php require_once './secciones/header.php'; ?>

    <!--================Banner Area =================-->
        <section class="banner_area">
            <div class="container">
                <div class="banner_text_inner">
                    <h4>Sobre Patrones de comportamiento</h4>
                </div>
            </div>
        </section>

        <section class="container" >
            <h5 class="text-center" style="margin-top: 20px;"><strong>¿Qué son los patrones de comportamiento?</strong></h5>
            <div class="media">
                <img class="d-flex align-self-start mr-3" src="./img/patrones/comportamiento.jpg" style="width: 100px; height: 80px; border-radius: 10px;" alt="Imagen no disponible.">
                <div class="media-body">
                    <p>son aquellos que están relacionados con algoritmos y con la asignación de responsabilidades a los objetos. Describen 
                        no solamente patrones de objetos o de clases, sino que también engloban patrones de comunicación entre ellos. </p>
                </div>
            </div>

            <!-- Sección de testimonials -->
            <?php require_once './secciones/testimonials.php'; ?>

        <div class="service_area" style="height: 500px; padding: 10px;">
            <h3 style="margin-bottom: 75px; margin-top: 10px; color: #fff;" class="text-center">Tipos de comportamientos</h3>
            <div class="row">

                <div class="col-lg-3"></div>

                <div class="col-lg-3">
                    <div style="max-width: 20rem; font-size: 18px; color: #fff;">
                        <div class="text-center"><strong><< Command >></strong>
                            <p>Principales agentes</p>
                        </div>
                        <div class="card-body">
                            <p>► Command</p><br>
                            <p>► ConcreteCommand</p><br>
                            <p>► Client</p><br>
                            <p>► Invoker</p><br>    
                            <p>► Receiver</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3">
                    <div style="max-width: 20rem; font-size: 18px; color: #fff;">
                        <div class="text-center"><strong><< Iterator >></strong>
                            <p>Principales agentes</p>
                        </div>
                        <div class="card-body">
                            <p>► ConcreteIterator</p><br>
                            <p>► Aggregate</p><br>
                            <p>► ConcreteAggregate</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3"></div>
            </div>

        </div>
            
        </section>

    <?php require_once './secciones/latest-news.php'; ?>


    <?php require_once './secciones/footer.php'; ?>

    <?php require_once './secciones/scripts.php'; ?>
    
</body>
</html>