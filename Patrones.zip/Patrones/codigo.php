<!DOCTYPE html>
<html lang="en">
<head>
	<?php require_once './secciones/head.php' ?>
</head>


<body>
    <?php require_once './secciones/header.php'; ?>
    
    <section class="banner_area">
            <div class="container">
                <div class="banner_text_inner">
                    <h4>Sobre Patrones de comportamiento</h4>
                </div>
            </div>
        </section>

<section class="faq-area pt-100 pb-100 " id="codigo">
			<div class="container" style="margin-top: 50px;">
                <h2 class="text-center text-uppercase text-black">Código</h2>
                <hr class="star-light mb-5">
				
				<div class="row">

					<div class="col-sm-6">
						<button class="btn btn-lg btn-outline-success col-sm-12" data-toggle="modal" data-target="#command-modal">Command</button>
						<br><br>
						<button class="btn btn-lg btn-outline-info col-sm-12" data-toggle="modal" data-target="#observer-modal">Observer</button>
						<br><br>
						<button class="btn btn-lg btn-outline-warning col-sm-12" data-toggle="modal" data-target="#chain-modal">Chain of Resp.</button>
						
					</div>
						
					<div class="col-sm-6">	
						<button class="btn btn-lg btn-outline-warning col-sm-12" data-toggle="modal" data-target="#strategy-modal">Strategy</button>
						<br><br>
						<button class="btn btn-lg btn-outline-info col-sm-12" data-toggle="modal" data-target="#iterator-modal">Iterator</button>
						<br><br>
						<button class="btn btn-lg btn-outline-success col-sm-12" data-toggle="modal" data-target="#visitor-modal">Visitor</button>
					</div>					
			    </div>	
                   

<div class="modal fade" id="command-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Patron command - codigo</h4>
            </div>

            <div class="modal-body">
                    <pre class="brush: html">
            /* The Invoker class */
            // Manejador
class Expendedor {
    constructor(unidades) {
        var valorDelBillete = unidades;
        var sucesor;
        this.siguiente = function (expendedor) {
            sucesor = expendedor;
        };
        this.cambiar = function (cantidad) {
            var numeroDeBilletes = Math.floor(cantidad / valorDelBillete);
            var noDispensable = cantidad - (numeroDeBilletes * valorDelBillete);
            if (numeroDeBilletes > 0) {
                console.log(numeroDeBilletes + ' billetes de ' +
                    valorDelBillete + ' dispensados');
            }
            if (noDispensable > 0 && sucesor) {
                sucesor.cambiar(noDispensable);
            }
            else if (noDispensable) {
                console.log('No se ha podido dar cambio de ' + noDispensable);
            }
        };
    }
}

// Cliente
class MaquinaDeCambio {
    constructor(expendedor) {
        var expendedorInicial = expendedor;
        this.darCambioDe = function (cantidad) {
            expendedorInicial.cambiar(cantidad);
        };
    }
}

// Manejadores Concreto
var expendedorDeUnaUnidad = new Expendedor(1);
var expendedorDeCincoUnidades = new Expendedor(5);
var expendedorDeDiezUnidades = new Expendedor(10);
var expendedorDeVeinteUnidades = new Expendedor(20);
var expendedorDeCincuentaUnidades = new Expendedor(50);

// Establecer cadena:
expendedorDeCincuentaUnidades.siguiente( expendedorDeVeinteUnidades );
expendedorDeVeinteUnidades.siguiente( expendedorDeDiezUnidades );
expendedorDeDiezUnidades.siguiente( expendedorDeCincoUnidades );
expendedorDeCincoUnidades.siguiente( expendedorDeUnaUnidad );


// Ejemplo de uso
var maquinaDeCambio = new MaquinaDeCambio(expendedorDeCincuentaUnidades);
maquinaDeCambio.darCambioDe(123);
            </pre>
            <div class="modal-footer">
            <button type="button" class="btn bnt-primary" data-dismiss="modal">Cerrar</button>
            </div>

            </div>    

        </div>

    </div>    
</div>
                <!-- Modal 2 commond -->

<div class="modal fade" id="observer-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Patron observer - codigo</h4>
            </div>

            <div class="modal-body">
                    <pre class="brush: html">

                class SubjectES6{
                    constructor(){
                        this.observer = [];
                    }
                
                suscribe(observer){
                    this.observer.push(observer);
                }

                unsuscribe(observer){
                    let index = this.observer.indexOf(observer);
                        if(index >-1){
                            this.observer.slice(index, 1):
                        }
                }
                
                notifyAll(){
                    for(let o of this observers)
                    console.log(o.name, "has been notified")
                }
            }

            </pre>
            <div class="modal-footer">
            <button type="button" class="btn bnt-primary" data-dismiss="modal">Cerrar</button>
            </div>

            </div>    

        </div>

    </div>    
</div>

   <!-- Modal 3 chain of resp. -->

<div class="modal fade" id="chain-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Patron chain of Responsibility - codigo</h4>
            </div>

            <div class="modal-body">
                    <pre class="brush: html">

'use strict';
class Handler {
    constructor() {
    }
    HandleRequest() {
    }
}

class ConcreteHandler1 extends Handler {
    constructor() {
        super()
        facade.log('ConcreteHandler1 created')
    }

    setSuccessor (successor) {
        this.successor = successor
    }

    HandleRequest(request) {
        if (request === 'run')
            facade.log('ConcreteHandler1 has handled the request')
        else {
            facade.log('ConcreteHandler1 calls his successor')
            this.successor.HandleRequest(request)
        }
    }
}

class ConcreteHandler2 extends Handler {
    constructor() {
        super()
        facade.log('ConcreteHandler2 created')
    }

    HandleRequest(request) {
        facade.log('ConcreteHandler2 has handled the request')
    }
}

function init_ChainofResponsibility() {
    let handle1 = new ConcreteHandler1()
    let handle2 = new ConcreteHandler2()
    handle1.setSuccessor(handle2)
    handle1.HandleRequest('run')
    handle1.HandleRequest('stay')

}

            </pre>
            <div class="modal-footer">
            <button type="button" class="btn bnt-primary" data-dismiss="modal">Cerrar</button>
            </div>

            </div>    

        </div>

    </div>    
</div>

        <!-- Modal 4 Strategy -->

<div class="modal fade" id="strategy-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Patron Strategy - codigo</h4>
            </div>

            <div class="modal-body">
                    <pre class="brush: html">

                'use strict';

class Contexttt {
    constructor(type){
        switch(type) {
            case "A":
                this.strategy = new ConcreteStrategyA()
                break
            case "B":
                this.strategy = new ConcreteStrategyB()
                break
            default:
                this.strategy = new ConcreteStrategyA()
        }
    }

    ContextInterface (){
        this.strategy.AlgorithmInterface()
    }
}

class Strategy {
    constructor() {
    }

    AlgorithmInterface (){
    }
}

class ConcreteStrategyA extends Strategy{
    constructor() {
        super()
        facade.log('ConcreteStrategyA created')
    }

    AlgorithmInterface (){
        facade.log('ConcreteStrategyA algorithm')
    }
}

class ConcreteStrategyB extends Strategy{
    constructor() {
        super()
        facade.log('ConcreteStrategyB created')
    }

    AlgorithmInterface (){
        facade.log('ConcreteStrategyB algorithm')
    }
}

function init_Strategy() {
    let contextA = new Contexttt("A")
    contextA.ContextInterface()
    let contextB = new Contexttt("B")
    contextB.ContextInterface()
}

            </pre>
            <div class="modal-footer">
            <button type="button" class="btn bnt-primary" data-dismiss="modal">Cerrar</button>
            </div>

            </div>    

        </div>

    </div>    
</div>

 <!-- Modal 5 Iterator -->

<div class="modal fade" id="iterator-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Patron Iterator - codigo</h4>
            </div>

            <div class="modal-body">
                    <pre class="brush: html">
                    'use strict';

class Iterator {
    constructor() {
    }

    First (){
    }

    Next (){
    }

    IsDone (){
    }

    CurrentItem (){
    }
}

class ConcreteIterator extends Iterator {
    constructor(aggregate) {
        super()
        facade.log('ConcreteIterator created')
        this.index = 0
        this.aggregate = aggregate
    }

    First (){
        return this.aggregate.list[0]
    }

    Next (){
        this.index += 2
        return this.aggregate.list[this.index]
    }

    CurrentItem (){
        return this.aggregate.list[this.index]
    }
}

class Aggregate {
    constructor() {
    }

    CreateIterator (){
    }
}

class ConcreteAggregate extends Aggregate {
    constructor(list) {
        super()
        this.list = list
        facade.log('ConcreteAggregate created')
    }

	CreateIterator (){
		this.iterator = new ConcreteIterator(this);
    }
}

function init_Iterator() {
    var aggregate = new ConcreteAggregate([0,1,2,3,4,5,6,7])
    aggregate.CreateIterator()
    facade.log(aggregate.iterator.First())
    facade.log(aggregate.iterator.Next())
    facade.log(aggregate.iterator.CurrentItem())
}

            </pre>
            <div class="modal-footer">
            <button type="button" class="btn bnt-primary" data-dismiss="modal">Cerrar</button>
            </div>

            </div>    

        </div>

    </div>    
</div>

 <!-- Modal 6 Visitor -->

<div class="modal fade" id="visitor-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4>Patron Visitor - codigo</h4>
            </div>

            <div class="modal-body">
                    <pre class="brush: html">
                    'use strict';

class Visitor {
    constructor() {
    }

    VisitConcreteElementA (ConcreteElementA){
    }

    VisitConcreteElementB (ConcreteElementB){
    }  
}

class ConcreteVisitor1 extends Visitor {
    constructor() {
        super()
        facade.log("ConcreteVisitor1 created");
    }

    VisitConcreteElementA (ConcreteElementA){
        facade.log("ConcreteVisitor1 visited ConcreteElementA");
    }

    VisitConcreteElementB (ConcreteElementB){
        facade.log("ConcreteVisitor1 visited ConcreteElementB");
    }  
}

class ConcreteVisitor2 extends Visitor {
    constructor() {
        super()
        facade.log("ConcreteVisitor2 created");
    }

    VisitConcreteElementA (ConcreteElementA){
        facade.log("ConcreteVisitor2 visited ConcreteElementA");
    }

    VisitConcreteElementB (ConcreteElementB){
        facade.log("ConcreteVisitor2 visited ConcreteElementB");
    }  
}

class ObjectStructure {
    constructor() {
        facade.log("ObjectStructure created");
    }
}

class Element {
    constructor() {
    }

    Accept (visitor){
    }
}

class ConcreteElementA extends Element {
    constructor() {
        super()
        facade.log("ConcreteElementA created");
    }

    Accept (visitor){
        visitor.VisitConcreteElementA(this);
    }

    OperationA (){
        facade.log("ConcreteElementA OperationA");  
    }
}

class ConcreteElementB extends Element {
    constructor() {
        super()
        facade.log("ConcreteElementB created");
    }

    Accept (visitor){
        visitor.VisitConcreteElementB(this);
    }

    OperationB (){
        facade.log("ConcreteElementB OperationB");  
    }
}


function init_Visitor() {
    let visitor1 = new ConcreteVisitor1();
    let visitor2 = new ConcreteVisitor2();
    let elementA = new ConcreteElementA();
    let elementB = new ConcreteElementB();
    elementA.Accept(visitor1);
    elementB.Accept(visitor2);
}

            </pre>
            <div class="modal-footer">
            <button type="button" class="btn bnt-primary" data-dismiss="modal">Cerrar</button>
            </div>

            </div>    

        </div>

    </div>    
</div>		<!-- End Modals Area -->
    		</div>
</section>
<br><br><br><br><br><br><br><br>
  <!--====== Footer ======-->
  <?php require_once 'secciones/footer.php'; ?>

<!--====== Scripts ======-->
<?php require_once 'secciones/scripts.php'; ?>

</body>
</html>


		