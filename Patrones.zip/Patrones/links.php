<!DOCTYPE html>
<html lang="en">
<head>
	<?php require_once 'secciones/head.php'; ?>
</head>


<body>
	<?php require_once 'secciones/header.php'; ?>  

	<section class="banner_area">
            <div class="container">
                <div class="banner_text_inner">
                    <h4>Sobre Patrones de comportamiento</h4>
                </div>
            </div>
        </section>

<!-- Start Conatct- Area -->
<section class="contact-area pt-100 pb-100 relative" id="documentacion" style="margin-top: 50px;">
			<div class="overlay overlay-bg"></div>
			<div class="container">
				
				<h2 class="text-center text-uppercase text-secondary mb-0">Documentacion Oficial</h2>
					<hr class="star-dark mb-5">
					<div class="row">
					<div class="col-lg-8 row mx-auto">
						<!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
						<!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
						<div class="col-md-6 docuLeft">
						<h5 class="text-center text-uppercase">SOBRE PATRONES</h5><br><br>
						<a href="https://sourcemaking.com/design_patterns/behavioral_patterns" class="btn btn-outline-dark btn-lg btn-block">Patrones PHP</a><br>
						<a href="https://www.dofactory.com/javascript/design-patterns" class="btn btn-outline-dark btn-lg btn-block">Patrones JS</a><br>
						<a href="https://github.com/Badacadabra/JavaScript-Design-Patterns" class="btn btn-outline-dark btn-lg btn-block">Patrones ES6</a><br>
						</div>
						<div class="col-md-6 docuRight">
						<h5 class="text-center text-uppercase">REPOSITORIO EN GITHUB</h5><br>
						<a href="https://github.com/ObedCastro/Tarea_Ingenieria_Software.git">
							<img src="img/Octocat.png" class="img-fluid">
						</a>
						</div>
					</div>
				</div>
				
			</div>
		</section>		<!-- End Conatct- Area -->

		  <!--====== Footer ======-->
		  <?php require_once 'secciones/footer.php'; ?>

<!--====== Scripts ======-->
<?php require_once 'secciones/scripts.php'; ?>

</body>
</html>
