<!DOCTYPE html>
<html lang="es">
    <head>
        <?php require_once 'secciones/head.php'; ?>
    </head>

    <body>

        <!--====== Search bar =======-->
        <?php require_once 'secciones/serach-bar.php'; ?>

        <!--====== Header ======-->
        <?php require_once 'secciones/header.php'; ?>

        <!--====== Slider ======-->
        <?php require_once 'secciones/slider.php'; ?>

        <!--======= Features =======-->
        <?php require_once 'secciones/features.php'; ?>
        <br><br>

        <!--======= Industries ======-->
        <!-- <?php require_once 'secciones/industries.php'; ?> -->

        <!--====== Service ======-->
        <?php  require_once 'secciones/services.php'; ?>

        <!--====== Testimonials ======-->
        

        <!--====== Project ======-->
        

        <!--================Latest News Area =================-->
        

        <!--====== Footer ======-->
        <?php require_once 'secciones/footer.php'; ?>

        <!--====== Scripts ======-->
       <?php require_once 'secciones/scripts.php'; ?>

    </body>
</html>
