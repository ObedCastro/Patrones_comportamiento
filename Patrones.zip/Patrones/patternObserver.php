<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require_once './secciones/head.php'; ?>
    </head>
    <body>

        <!-- Header -->
        <?php require_once './secciones/header.php'; ?>

        <!--================Banner Area =================-->
        <section class="banner_area">
            <div class="container">
                <div class="banner_text_inner">
                    <h4>Pattern Observer</h4>
                </div>
            </div>
        </section>

        <!--================Static Area =================-->
        <section class="static_area">
            <div class="container">
                <div class="static_inner">
                <div class="row">
                        <div class="col-lg-9">
                            <div>
                                <h3 style="margin-bottom: 15px;"><strong>Descripción</strong></h3>
                                <p style="margin-bottom: 25px;">El patrón Observer ofrece un modelo de suscripción en el que <strong>los objetos 
                                    se suscriben a un evento y reciben una notificación cuando se produce el evento</strong>. Este patrón es la piedra 
                                    angular de la programación dirigida por eventos, incluido JavaScript. El patrón Observer facilita un buen 
                                    diseño orientado a objetos y promueve un acoplamiento suelto. </p>

                                <p style="margin-bottom: 25px;">Al crear aplicaciones web, terminas escribiendo muchos controladores de eventos. 
                                    Los controladores de eventos son funciones que se notificarán cuando se active un evento determinado. Estas 
                                    notificaciones reciben opcionalmente un argumento de evento con detalles sobre el evento 
                                    (por ejemplo, la posición x y y del mouse en un evento de clic).</p>

                                <p style="margin-bottom: 25px;">El paradigma de evento y controlador de eventos en JavaScript es la 
                                    manifestación del patrón de diseño Observer. Otro nombre para el patrón Observer es <strong>Pub/Sub</strong>, abreviatura 
                                    de <strong>Publicación/Suscripción</strong>.</p>
                            </div>
                            <div class="static_img text-center" style="border: 1px solid grey; border-radius: 10px; padding: 10px;">
                                <p style="font-size: 20px; margin-bottom: 15px;">Diagrama</p>
                                <img class="img-fluid" src="img/patrones/diagram-patternObserver.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="right_sidebar_area">
                                <aside class="right_widget r_news_widget">
                                    <div class="r_w_title">
                                        <h3>Participantes</h3>
                                    </div>
                                    <div class="news_inner">
                                        <div class="news_item">
                                            <h4><strong>Los objetos que participan en éste patrón son</strong></h4>
                                            <h4>Sujeto: en el código de muestra: Click 
                                                mantiene la lista de observadores. Cualquier número de objetos Observadores puede observar que Subject 
                                                implementa una interfaz que permite que los objetos observadores se suscriban o cancelen la suscripción 
                                                envía una notificación a sus observadores cuando cambia su estado</h4>
                                        </div>
                                        <div class="news_item">
                                            <h4>Observadores: en el código de muestra: clickHandler 
                                                tiene una firma de función que se puede invocar cuando Cambios en el sujeto (es decir, evento ocurre) </h4>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Static Area =================-->

        <!--================Footer Area =================-->
        <?php require_once './secciones/footer.php'; ?>
        <!--================End Footer Area =================-->


        <?php require_once './secciones/scripts.php'; ?>
    </body>
</html>
