<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require_once './secciones/head.php'; ?>
    </head>
    <body>

        <!-- Header -->
        <?php require_once './secciones/header.php'; ?>

        <!--================Banner Area =================-->
        <section class="banner_area">
            <div class="container">
                <div class="banner_text_inner">
                    <h4>Pattern Strategy</h4>
                </div>
            </div>
        </section>

        <!--================Static Area =================-->
        <section class="static_area">
            <div class="container">
                <div class="static_inner">
                <div class="row">
                        <div class="col-lg-9">
                            <div>
                                <h3 style="margin-bottom: 15px;"><strong>Descripción</strong></h3>
                                <p style="margin-bottom: 25px;">El patrón de Estrategia encapsula algoritmos (o estrategias) alternativos 
                                    para una tarea en particular. Permite que un método se <strong>intercambie</strong> en tiempo de ejecución por cualquier 
                                    otro método (estrategia) sin que el cliente se dé cuenta. Esencialmente, <strong>la estrategia es un grupo de 
                                    algoritmos que son intercambiables</strong>.</p>

                                <p style="margin-bottom: 25px;">Supongamos que nos gusta probar el rendimiento de diferentes algoritmos de 
                                    clasificación para una serie de números: ordenación de concha, clasificación de pila, clasificación de burbuja,
                                    ordenación rápida, etc. La aplicación del patrón de Estrategia a estos algoritmos permite que el programa de 
                                    prueba recorra todos los algoritmos, simplemente cambiándolos en el tiempo de ejecución y prueba cada uno de 
                                    estos contra la matriz. Para que la Estrategia funcione, todas las firmas de métodos deben ser iguales para que 
                                    puedan variar sin que el programa cliente lo sepa.</p>

                                <p style="margin-bottom: 25px;">En JavaScript, el patrón de Estrategia se usa ampliamente como un <strong>mecanismo
                                    de complemento cuando se crean marcos extensibles</strong>. Esto puede ser un enfoque muy eficaz. Para obtener más 
                                    información, consulte nuestro JavaScript + jQuery Design Pattern Framework.</p>
                            </div>
                            <div class="static_img text-center" style="border: 1px solid grey; border-radius: 10px; padding: 10px;">
                                <p style="font-size: 20px; margin-bottom: 15px;">Diagrama</p>
                                <img class="img-fluid" src="img/patrones/diagram-patternStrategy.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="right_sidebar_area">
                                <aside class="right_widget r_news_widget">
                                    <div class="r_w_title">
                                        <h3>Participantes</h3>
                                    </div>
                                    <div class="news_inner">
                                        <div class="news_item">
                                            <h4><strong>Los objetos que participan en éste patrón son</strong></h4>
                                            <h4>Contexto: en el código de ejemplo: Shipping 
                                                mantiene una referencia a la interfaz actual de Strategy object 
                                                que permite a los clientes solicitar los cálculos de Strategy 
                                                permite a los clientes cambiar Strategy</h4>
                                        </div>
                                        <div class="news_item">
                                            <h4>Strategy - En el código de ejemplo: UPS, USPS, Fedex 
                                                implementa el algoritmo usando la interfaz de estrategia</h4>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Static Area =================-->

        <!--================Footer Area =================-->
        <?php require_once './secciones/footer.php'; ?>
        <!--================End Footer Area =================-->


        <?php require_once './secciones/scripts.php'; ?>
    </body>
</html>
