<section class="industries_area">
    <div class="left_indus">
        <div class="indus_img">
            <img src="img/indus-laptop.png" alt="">
        </div>
    </div>
    <div class="right_indus">
        <div class="indus_text">
            <div class="main_title">
                <h2>We Serve All Industries</h2>
                <p>We stay on top of our industry by being experts in yours. We measure our success by the results we drive for our clients.</p>
            </div>
            <div class="our_skill_inner">
                <div>
                <div class="single_skill">
                    <div>
                    <h3>Website Design</h3>
                    <br>
                    </div>
                    <div class="progress" data-value="30">
                        <div class="progress-bar">
                            <div class="progress_parcent"><span class="counter">30</span>%</div>
                        </div>
                    </div>
                </div>
                <div class="single_skill">
                    <h3>Brand Strategy</h3>
                    <div class="progress" data-value="95">
                        <div class="progress-bar">
                            <div class="progress_parcent"><span class="counter">95</span>%</div>
                        </div>
                    </div>
                </div>
                <div class="single_skill">
                    <h3>Digital Marketing</h3>
                    <div class="progress" data-value="85">
                        <div class="progress-bar">
                            <div class="progress_parcent"><span class="counter">85</span>%</div>
                        </div>
                    </div>
                </div>
                <div class="single_skill">
                    <h3>Website Development</h3>
                    <div class="progress" data-value="90">
                        <div class="progress-bar">
                            <div class="progress_parcent"><span class="counter">90</span>%</div>
                        </div>
                    </div>
                </div>
            </div>
            <a class="read_btn" href="#">Work with us</a>
        </div>
    </div>
</section>