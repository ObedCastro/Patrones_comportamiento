<section class="creative_feature_area">
    <div class="container">
        <div class="c_feature_box">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center">
                        <h3>Características de los patrones</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="c_box_item">
                        <h4 class="text-center"><strong>Contexto</strong></h4>
                        <p>Situación en la que se presenta el problema de diseño. </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="c_box_item">
                        <h4 class="text-center"><strong>Problema</strong></h4>
                        <p>Descripción del problema a resolver, y enumeración de las fuerzas a equilibrar 
                            (requisitos no funcionales como eficiencia, portabilidad, cambiabilidad, …).</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="c_box_item">
                        <h4 class="text-center"><strong></i>Solución</strong></h4>
                        <p>Conjunto de medidas que se han de tomar, como crear alguna clase, atributo o método,
                            nuevos comportamientos entre clases, … </p>
                    </div>
                </div>
            </div>
        </div>
        <!--
        <div class="digital_feature p_100">
            <div class="row">
                <div class="col-lg-6">
                    <div class="d_feature_text">
                        <div class="main_title">
                            <h2>We Are A Creative <br /> Digital Agency Focused on Growing Brands Online</h2>
                        </div>
                        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderi.</p>
                        <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia dese mollit anim id est laborum. Sed ut perspiciatis unde omnis iste.</p>
                        <a class="read_btn" href="#">Read more</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="d_feature_img">
                        <img src="img/feature-right.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>-->
    </div>
</section>