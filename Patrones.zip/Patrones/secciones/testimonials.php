<section class="testimonials_area p_100" style="height: 300px; padding-top: 20px;">
    <div class="container">
        <div class="testimonials_slider owl-carousel">
            <div class="item">
                <div class="media">
                    <div class="media-body">
                        <img src="img/dotted-icon.png" alt="">
                        <p>Los patrones de diseño están relacionados con el flujo de control del sistema.</p>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="media">
                    <div class="media-body">
                        <img src="img/dotted-icon.png" alt="">
                        <p>Ciertas formas de organizar el control en un sistema, pueden derivar de grandes beneficios para la 
                            eficiencia y el mantenimiento del sistema.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>