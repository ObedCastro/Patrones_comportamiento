<section class="project_area">
    <div class="container">
        <div class="project_inner">
            <div class="center_title">
                <h2>Ready To Discuss Your Project? </h2>
                <p>There are many ways to contact us. You may drop us a line, give us a call or send an email, choose what suits you the most.</p>
            </div>
            <a class="tp_btn" href="#">WORK WITH US</a>
        </div>
    </div>
</section>