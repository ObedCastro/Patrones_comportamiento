<footer class="footer_area" >
    <div class="footer_widgets_area">
        <div class="container">
            <div class="f_widgets_inner row">
                <div class="col-lg-3 col-md-5">
                    <aside class="f_widget subscribe_widget">
                        <div class="f_w_title">
                            <h3>ASIGNATURA </h3>
                        </div>
                        <p>Ingenieria de Software   </p>
                        <p> Ciclo II - 2018</p>
                        <div class="input-group">
                            
                            <span class="input-group-btn">
                                <li class="nav-item active">  <a class="nav-link" href="https://github.com/ObedCastro/Tarea_Ingenieria_Software.git">   <button class="btn btn-secondary submit_btn" style="padding: 10px;" type="button">DESCARGAR DE GITHUB </button></a></li> 
                            </span>
                        </div>
                        <ul>
                            
                            <li><a><i class="GITHUB"></i></a></li>
                        </ul>
                    </aside>
                </div>
              
                <div class="col-lg-5 col-md-6">
                    <aside class="f_widget contact_widget">
                        <div class="f_w_title">
                            <h3>UNIVERSIDAD DE EL SALVADOR</h3>
                        </div>
                        
							<img src="img/Minerva.png" class="img-fluid">
						</a>

                           
                        
                    </aside>
                </div>
                <div class="col-lg-3 col-md-5">
                    <aside class="f_widget contact_widget">
                        <div class="f_w_title">
                            <h3>DESARROLLADORES</h3>
                            <div>
                            <p><a href="https://www.facebook.com/ObeeyCast">Obed Alberto Castro</a></p>
                            <p><a href="https://www.facebook.com/neko.sakurai">Grecia Guadalupe Escobar</a></p>
                            <p><a href="https://www.facebook.com/Jimart007">Junior Mario Jimenez</a></p>
                            </div>
                        </div>                         
                    </aside>
                </div>
            </div>
        </div>
    </div>
    <div class="copy_right_area">
        <div class="container">
            <div class="float-md-left">
                <h5>Copyright &copy;<script>document.write(new Date().getFullYear());</script> Todos los derechos reservados</h5>
            </div>
            <div class="float-md-right">
                
            </div>
        </div>
    </div>
</footer>