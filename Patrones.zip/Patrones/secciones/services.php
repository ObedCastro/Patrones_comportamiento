<section class="service_area">
    <div class="container">
        <div class="center_title">
            <h2>Ventajas de los patrones de diseño</h2>
        </div>
        <div class="row service_item_inner">
            <div class="col-lg-6">
                <div class="service_item">
                    <i class="ti-ruler-pencil"></i>
                    <h4>Resistencia al cambio</h4>
                    <p>Se debe elegir el patrón que facilite lo más posibles futuros cambios. Los cambios en un diseño no son probables, 
                        son seguros, se producen con toda seguridad. A la hora de diseñar una solución a un problema es conveniente 
                        abstraer el problema concreto a otro más genérico y resolver este último. Los patrones consiguen precisamente esto.</p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="service_item">
                    <i class="ti-desktop"></i>
                    <h4>Reutilización</h4>
                    <p>Éste aspecto requiere una aclaración importante. La reutilización de código resulta prácticamente imposible. 
                        En cambio, los diseños son mucho más reutilizables, pero ni siquiera tanto como las propias ideas. Se debe tender 
                        a reutilizar las ideas. Por eso, cuando hacemos un diseño debemos pensar en que nos debe ser útil para futuros 
                        proyectos, en su esencia o filosofía, no en su estructura o implementación. Así, lo conveniente es buscar patrones 
                        nuevos en diseños nuevos, documentarlos y almacenarlos como una parte importante de nuestra experiencia. Son como una 
                        "álbum de fotos" de nuestros viajes</p>
                </div>
            </div>
        </div>
    </div>
</section>