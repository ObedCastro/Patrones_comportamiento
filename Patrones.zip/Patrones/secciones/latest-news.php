<section class="latest_news_area p_100">
    <div class="container">
        <div class="b_center_title">
            <h3>Otros tipos de comportamientos</h3>
        </div>
        <div class="l_news_inner">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="l_news_item">
                        <div class="l_news_content">
                            <div class="text-center"><strong><< Observer >></strong>
                                <p>Principales agentes</p>
                                <p>▼</p>
                            </div>
                            <div>
                                <p>El patrón de comportamiento Observer define una interacción entre objetos, de manera que 
                                    cuando uno de ellos cambia su estado, el Observer se encarga de notificar este cambio a los demás.
                                    Por tanto, la razón de ser de este patrón es desacoplar las clases de los objetos, aumentando la modularidad 
                                    del lenguaje y evitando bucles de actualización.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="l_news_item">
                        <div class="l_news_content">
                            <div class="text-center"><strong><< Strategy >></strong>
                                <p>Principales agentes</p>
                                <p>▼</p>
                            </div>
                            <div>
                                <p>Determina la forma de implementar el intercambio de mensajes entre diferentes objetos 
                                    que realizan diferentes tareas, pero que comparten elementos comunes. Permite gestionar un conjunto de 
                                    operaciones de entre los cuales el cliente puede elegir el que le convenga más en cada situación, e 
                                    intercambiarlo, de forma dinámica, cuando lo necesite.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>