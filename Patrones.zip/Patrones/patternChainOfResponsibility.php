<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require_once './secciones/head.php'; ?>
    </head>
    <body>

        <!-- Header -->
        <?php require_once './secciones/header.php'; ?>

        <!--================Banner Area =================-->
        <section class="banner_area">
            <div class="container">
                <div class="banner_text_inner">
                    <h4>Chain of Responsibility</h4>
                </div>
            </div>
        </section>

        <!--================Static Area =================-->
        <section class="static_area">
            <div class="container">
                <div class="static_inner">
                <div class="row">
                        <div class="col-lg-9">
                            <div>
                                <h3 style="margin-bottom: 15px;"><strong>Descripción</strong></h3>
                                <p style="margin-bottom: 25px;">El patrón de la Cadena de responsabilidad proporciona una cadena de objetos 
                                    acoplados de forma flexible, uno de los cuales puede <strong>satisfacer una solicitud</strong>. Este patrón es esencialmente 
                                    una búsqueda lineal de un objeto que puede manejar una solicitud en particular</p>

                                <p style="margin-bottom: 25px;">Un ejemplo de una cadena de responsabilidad es la propagación de eventos en 
                                    la cual un evento se propaga a través de una serie de controles anidados, uno de los cuales puede elegir 
                                    manejar el evento.</p>

                                <p style="margin-bottom: 25px;">Los patrones de la Cadena de responsabilidad <strong>están relacionados con el patrón 
                                    de encadenamiento</strong> que se usa frecuentemente en JavaScript (jQuery hace un uso extensivo de este patrón). </p>
                            </div>
                            <div class="static_img text-center" style="border: 1px solid grey; border-radius: 10px; padding: 10px;">
                                <p style="font-size: 20px; margin-bottom: 15px;">Diagrama</p>
                                <img class="img-fluid" src="img/patrones/diagram-patternChainOfResponsibility.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="right_sidebar_area">
                                <aside class="right_widget r_news_widget">
                                    <div class="r_w_title">
                                        <h3>Participantes</h3>
                                    </div>
                                    <div class="news_inner">
                                        <div class="news_item">
                                            <h4><strong>Los objetos que participan en éste patrón son</strong></h4>
                                            <h4>Cliente: en el código de muestra: Request 
                                                inicia la solicitud en una cadena de objetos de manejador</h4>
                                        </div>
                                        <div class="news_item">
                                            <h4>Controlador: en el código de muestra: Request.get () method 
                                                define una interfaz para manejar las solicitudes 
                                                implementa el enlace sucesor (devolviendo 'this')</h4>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Static Area =================-->

        <!--================Footer Area =================-->
        <?php require_once './secciones/footer.php'; ?>
        <!--================End Footer Area =================-->


        <?php require_once './secciones/scripts.php'; ?>
    </body>
</html>
