<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require_once './secciones/head.php'; ?>
    </head>
    <body>

        <!-- Header -->
        <?php require_once './secciones/header.php'; ?>

        <!--================Banner Area =================-->
        <section class="banner_area">
            <div class="container">
                <div class="banner_text_inner">
                    <h4>Pattern Command</h4>
                </div>
            </div>
        </section>

        <!--================Static Area =================-->
        <section class="static_area">
            <div class="container">
                <div class="static_inner">
                    <div class="row">
                        <div class="col-lg-9">
                            <div>
                                <h3 style="margin-bottom: 15px;"><strong>Descripción</strong></h3>
                                <p style="margin-bottom: 25px;"> El patrón de Comando encapsula acciones como objetos. Los objetos de comando permiten sistemas 
                                    acoplados libremente al separar los objetos que emiten una solicitud de los objetos que realmente 
                                    procesan la solicitud. Estas solicitudes se denominan <strong>eventos</strong> y el código que procesa las solicitudes 
                                    se denominan <strong>controladores de eventos</strong>.</p>

                                <p style="margin-bottom: 25px;">Suponga que está creando una aplicación que admite las acciones Cortar, Copiar y Pegar del portapapeles. 
                                    Estas acciones se pueden activar de diferentes maneras a través de la aplicación: <strong>mediante un sistema de menús,
                                    un menú contextual</strong> (por ejemplo, haciendo clic con el botón derecho en un cuadro de texto) o mediante un método 
                                    abreviado de teclado. </p>

                                <p style="margin-bottom: 25px;">Los objetos de comando le permiten centralizar el procesamiento de estas acciones, una para cada operación. 
                                    Por lo tanto, solo necesita un comando para procesar todas las solicitudes de corte, una para todas las 
                                    solicitudes de copia y otra para todas las solicitudes de pegado. 

                                    Dado que los comandos centralizan todo el procesamiento, también participan con frecuencia en el manejo de 
                                    la funcionalidad de Deshacer para toda la aplicación</p>
                            </div>
                            <div class="static_img text-center" style="border: 1px solid grey; border-radius: 10px; padding: 10px;">
                                <p style="font-size: 20px; margin-bottom: 15px;">Diagrama</p>
                                <img class="img-fluid" src="img/patrones/diagram-patternCommand.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="right_sidebar_area">
                                <aside class="right_widget r_news_widget">
                                    <div class="r_w_title">
                                        <h3>Participantes</h3>
                                    </div>
                                    <div class="news_inner">
                                        <div class="news_item">
                                            <h4><strong>Los objetos que participan en éste patrón son</strong></h4>
                                            <h4>Cliente: en el código de ejemplo: la función run() hace referencia al Objeto receptor</h4>
                                        </div>
                                        <div class="news_item">
                                            <h4>Receptor - En el código de ejemplo: Calculadora sabe cómo realizar la operación asociada con el comando 
                                                (opcionalmente) mantiene un historial de comandos ejecutados </h4>
                                        </div>
                                        <div class="news_item">
                                           <h4>Comando: en el código de muestra: Comando mantiene información sobre la acción que debe 
                                               realizarse</h4>
                                        </div>
                                        <div class="news_item">
                                            <h4>Invoker - En nuestro código de muestra: el usuario que presiona los botones 
                                            solicita realizar la solicitud</h4>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Static Area =================-->

        <!--================Footer Area =================-->
        <?php require_once './secciones/footer.php'; ?>
        <!--================End Footer Area =================-->


        <?php require_once './secciones/scripts.php'; ?>
    </body>
</html>
