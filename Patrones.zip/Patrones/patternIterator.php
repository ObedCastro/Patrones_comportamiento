<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require_once './secciones/head.php'; ?>
    </head>
    <body>

        <!-- Header -->
        <?php require_once './secciones/header.php'; ?>

        <!--================Banner Area =================-->
        <section class="banner_area">
            <div class="container">
                <div class="banner_text_inner">
                    <h4>Pattern Iterator</h4>
                </div>
            </div>
        </section>

        <!--================Static Area =================-->
        <section class="static_area">
            <div class="container">
                <div class="static_inner">
                    <div class="row">
                        <div class="col-lg-9">
                            <div>
                                <h3 style="margin-bottom: 15px;"><strong>Descripción</strong></h3>
                                <p style="margin-bottom: 25px;">El patrón de iterador permite a los clientes realizar un bucle efectivo sobre 
                                    una colección de objetos. 
                                    Una tarea de programación común es atravesar y manipular una colección de objetos. Estas colecciones 
                                    pueden almacenarse como una matriz o quizás algo más complejo, <strong>como un árbol o una estructura gráfica</strong>. 
                                    Además, es posible que deba acceder a los elementos de la colección en un cierto orden, como, de frente a 
                                    atrás, de atrás hacia adelante, primero la profundidad (como en las búsquedas en árbol), omitir objetos 
                                    numerados de manera uniforme, etc</p>

                                <p style="margin-bottom: 25px;">El diseño del iterador el patrón resuelve este problema separando la colección 
                                    de objetos del recorrido de estos objetos mediante la implementación de un <strong>iterador especializado</strong>.</p>

                                <p style="margin-bottom: 25px;">Hoy en día, muchos idiomas tienen iteradores incorporados al admitir 
                                    construcciones de tipo 'para-cada' e interfaces IEnumerable e IEnumerator. Sin embargo, <strong>JavaScript solo 
                                    admite bucles básicos en forma de, for-in, while, y while sentencias.</strong></p>
                                
                                <p style="margin-bottom: 25px;">El patrón Iterator permite a los desarrolladores de JavaScript diseñar construcciones en bucle que son 
                                    mucho más <strong>flexibles y sofisticadas</strong>.</p>
                            </div>
                            <div class="static_img text-center" style="border: 1px solid grey; border-radius: 10px; padding: 10px;">
                                <p style="font-size: 20px; margin-bottom: 15px;">Diagrama</p>
                                <img class="img-fluid" src="img/patrones/diagram-patternIterator.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="right_sidebar_area">
                                <aside class="right_widget r_news_widget">
                                    <div class="r_w_title">
                                        <h3>Participantes</h3>
                                    </div>
                                    <div class="news_inner">
                                        <div class="news_item">
                                            <h4><strong>Los objetos que participan en éste patrón son</strong></h4>
                                            <h4>Cliente: en el código de muestra: la función run () 
                                                referencia e invoca a Iterator con una colección de objetos </h4>
                                        </div>
                                        <div class="news_item">
                                            <h4>Iterator - En el código de muestra: Iterator 
                                                implementa la interfaz de iterador con los métodos primero (), next (), etc. 
                                                mantiene un registro de la corriente Posición al atravesar la colección </h4>
                                        </div>
                                        <div class="news_item">
                                           <h4>Artículos - En código de ejemplo: Elementos 
                                                objetos individuales de la colección que se está recorriendo</h4>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Static Area =================-->

        <!--================Footer Area =================-->
        <?php require_once './secciones/footer.php'; ?>
        <!--================End Footer Area =================-->


        <?php require_once './secciones/scripts.php'; ?>
    </body>
</html>
